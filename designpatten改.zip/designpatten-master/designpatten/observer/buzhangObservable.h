//HanFeiziObservable.h

#pragma once
#include "iobservable.h"
#include "IObserver.h"
#include <vector>
using std::vector;
class CbuzhangObservable :
	public IObservable
{
public:
	CbuzhangObservable(void);
	~CbuzhangObservable(void);
	void AddObserver(IObserver *pObserver);
	void DeleteObserver(IObserver *pObserver);
	void NotifyObservers(string context);
	void GiveTask();

private:
	vector<IObserver*> m_observerList;
	typedef vector<IObserver*>::const_iterator ObserverList_C_iterator;
};