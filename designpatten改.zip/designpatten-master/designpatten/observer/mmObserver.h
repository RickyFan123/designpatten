//mmObserver.h

#pragma once
#include "iobserver.h"
#include <iostream>
using std::string;
class CmmObserver :
	public IObserver
{
public:
	CmmObserver(void);
	~CmmObserver(void);
	void Update(string context);
	string GetName();
private:
	void Cry(string report);
};