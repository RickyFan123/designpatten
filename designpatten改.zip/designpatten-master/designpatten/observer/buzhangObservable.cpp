//HanFeiziObservable.cpp

#include "StdAfx.h"
#include "buzhangObservable.h"
#include <iostream>
using std::string;
using std::cout;
using std::endl;
CbuzhangObservable::CbuzhangObservable(void)
{
}
CbuzhangObservable::~CbuzhangObservable(void)
{
}
void CbuzhangObservable::AddObserver(IObserver *pObserver)
{
	m_observerList.push_back(pObserver);
}
void CbuzhangObservable::DeleteObserver(IObserver *pObserver)
{
	ObserverList_C_iterator it = m_observerList.begin();
	for (; it != m_observerList.end(); it++)
	{
		string name = (*it)->GetName();
		if (name.compare(pObserver->GetName()) == 0)
		{
			//�ҵ���ɾ����
		}
	}
}
void CbuzhangObservable::NotifyObservers(string context)
{
	ObserverList_C_iterator it = m_observerList.begin();
	for (; it != m_observerList.end(); it++)
	{
		(*it)->Update(context);
	}
}
void CbuzhangObservable::GiveTask()
{
	cout << "������Ҫ����������" << endl;

	this->NotifyObservers("�����ڸ�ÿ���鲼������");
}
