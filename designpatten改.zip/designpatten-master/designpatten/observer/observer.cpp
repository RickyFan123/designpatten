// Observer.cpp 
#include "stdafx.h"

#include "buzhangObservable.h"
#include "xzObserver.h"
#include "mmObserver.h"
#include <iostream>
using std::cout;
using std::endl;
using std::string;


void DoNewNew()
{
	//IObservable.h, buzhangObservable.h, IObserver.h, xzObserver.h
	IObserver *pxz = new CxzObserver();
	IObserver *pmm = new CmmObserver();

	CbuzhangObservable *pbuzhang = new CbuzhangObservable();

	pbuzhang->AddObserver(pxz);
	pbuzhang->AddObserver(pmm);
	pbuzhang->GiveTask();

	delete pxz;
	pxz = NULL;
	delete pbuzhang;
	pbuzhang = NULL;
}



int _tmain(int argc, _TCHAR* argv[])
{
	//�Ƚ�ԭʼ�ķ��������߳����۲졣
	//DoIt();


	DoNewNew();


		return 0;
}