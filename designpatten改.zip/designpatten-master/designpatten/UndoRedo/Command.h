

#ifndef command_h
#define command_h
class Command {
    
public:
    
    virtual void execute() = 0;
    
    
    virtual void undo() = 0;
    
    
    virtual ~Command() { }
    
};



#endif /* command_h */
