//xzObserver.h

#pragma once
#include "iobserver.h"
#include <iostream>
using std::string;
class CxzObserver :
	public IObserver
{
public:
	CxzObserver(void);
	~CxzObserver(void);
	void Update(string context);
	string GetName();
private:
	void Report(string report);
};